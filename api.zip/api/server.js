import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { MercadoPagoConfig, Preference } from 'mercadopago';
import axios from 'axios';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { validatePaymentData } from './middleware/validation.js';
import { securityLogger } from './middleware/security-logger.js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Security Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://www.mercadopago.com"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://api.mercadopago.com"],
      frameSrc: ["https://www.mercadopago.com"]
    }
  }
}));

// Rate Limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

// Apply rate limiting to all routes
app.use(limiter);

// Security logging
app.use(securityLogger);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    mercadopago: !!process.env.MERCADOPAGO_ACCESS_TOKEN,
    whatsapp: !!process.env.WHATSAPP_API_TOKEN
  });
});

// Specific rate limiting for payment endpoints
const paymentLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // limit each IP to 10 payment requests per windowMs
  message: 'Too many payment attempts from this IP, please try again later.',
});

// Middleware
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://tudominio.com'] 
    : ['http://localhost:4321', 'http://localhost:3000'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Configure MercadoPago
const client = new MercadoPagoConfig({ 
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN 
});

// Store for temporary data (in production, use a database)
const pendingPayments = new Map();

// 1. Create Payment Preference
app.post('/api/create-preference', paymentLimiter, validatePaymentData, async (req, res) => {
  try {
    console.log('Received request body:', req.body);
    
    const { 
      nombre, 
      email, 
      telefono, 
      provincia, 
      localidad, 
      modalidad, 
      cursos, 
      totalAmount,
      plan 
    } = req.body;

    // Create preference
    console.log('Creating MercadoPago preference with data:', {
      title: `Inscripción SIADE - ${cursos.join(', ')}`,
      unit_price: parseFloat(totalAmount),
      payer: { name: nombre, email: email }
    });
    
    const preference = new Preference(client);
    const result = await preference.create({
      body: {
        items: [
          {
            title: `Inscripción SIADE - ${cursos.join(', ')}`,
            unit_price: parseFloat(totalAmount),
            quantity: 1,
            currency_id: 'ARS'
          }
        ],
        payer: {
          name: nombre,
          email: email
        },
        back_urls: {
          success: `http://localhost:4321/success`,
          failure: `http://localhost:4321/failure`,
          pending: `http://localhost:4321/pending`
        },
        // auto_return: 'approved',
        external_reference: `SIADE_${Date.now()}`,
        notification_url: `${process.env.WEBHOOK_URL}/webhook`,
        expires: true,
        expiration_date_to: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
      }
    });
    
    // Store payment data temporarily
    const paymentId = result.id;
    pendingPayments.set(paymentId, {
      nombre,
      email,
      telefono,
      provincia,
      localidad,
      modalidad,
      cursos,
      totalAmount,
      createdAt: new Date()
    });

    res.json({
      success: true,
      preferenceId: paymentId,
      initPoint: result.init_point
    });

  } catch (error) {
    console.error('Error creating preference:', error);
    res.status(500).json({
      success: false,
      error: 'Error creating payment preference'
    });
  }
});

// 2. Webhook to receive MercadoPago notifications
app.post('/api/webhook', async (req, res) => {
  try {
    const { type, data } = req.body;

    if (type === 'payment') {
      const paymentId = data.id;
      
      // Get payment details from MercadoPago
      const payment = await mercadopago.payment.get(paymentId);
      
      if (payment.body.status === 'approved') {
        // Get stored data
        const paymentData = pendingPayments.get(payment.body.external_reference);
        
        if (paymentData) {
          // Send WhatsApp notification
          await sendWhatsAppNotification(paymentData, payment.body);
          
          // Remove from pending payments
          pendingPayments.delete(payment.body.external_reference);
          
          console.log(`Payment approved: ${paymentId}`);
        }
      }
    }

    res.status(200).send('OK');
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).send('Error');
  }
});

// 3. WhatsApp Notification Function
async function sendWhatsAppNotification(paymentData, paymentInfo) {
  try {
    const message = formatWhatsAppMessage(paymentData, paymentInfo);
    
    const response = await axios.post(
      `https://graph.facebook.com/v17.0/${process.env.WHATSAPP_PHONE_ID}/messages`,
      {
        messaging_product: 'whatsapp',
        to: paymentData.telefono.replace(/\D/g, ''), // Remove non-digits
        type: 'text',
        text: {
          body: message
        }
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.WHATSAPP_API_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('WhatsApp notification sent successfully');
    return response.data;
  } catch (error) {
    console.error('Error sending WhatsApp notification:', error);
    throw error;
  }
}

// 4. Format WhatsApp Message
function formatWhatsAppMessage(paymentData, paymentInfo) {
  const coursesList = paymentData.cursos.map(curso => `• ${curso}`).join('\n');
  const paymentDate = new Date().toLocaleString('es-AR');
  
  return `🎓 ¡Nueva Inscripción Confirmada!

👤 Alumno: ${paymentData.nombre}
📧 Email: ${paymentData.email}
📱 Teléfono: ${paymentData.telefono}
🏫 Provincia: ${paymentData.provincia}
📍 Localidad: ${paymentData.localidad}
📚 Modalidad: ${paymentData.modalidad}

📚 Cursos Seleccionados:
${coursesList}

💰 Pago: $${paymentData.totalAmount} - ${paymentInfo.payment_method.type}
🆔 ID de Pago: ${paymentInfo.id}
✅ Estado: Pago Aprobado
📅 Fecha: ${paymentDate}

📋 Próximos pasos:
1. Recibirás acceso a la plataforma en 24h
2. Material de estudio disponible
3. Soporte técnico activo

¡Bienvenido a la familia SIADE! 🎉

Para consultas: +54 9 11 1234-5678`;
}

// 5. Success page handler
app.get('/api/success', (req, res) => {
  res.json({
    success: true,
    message: 'Payment successful! You will receive a WhatsApp confirmation shortly.'
  });
});

// 6. Failure page handler
app.get('/api/failure', (req, res) => {
  res.json({
    success: false,
    message: 'Payment failed. Please try again.'
  });
});

// 7. Pending page handler
app.get('/api/pending', (req, res) => {
  res.json({
    success: false,
    message: 'Payment is pending. You will be notified once confirmed.'
  });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 API Server running on port ${PORT}`);
  console.log(`📱 WhatsApp integration: ${process.env.WHATSAPP_API_TOKEN ? 'Configured' : 'Not configured'}`);
  console.log(`💳 MercadoPago integration: ${process.env.MERCADOPAGO_ACCESS_TOKEN ? 'Configured' : 'Not configured'}`);
});

export default app; 