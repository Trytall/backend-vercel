// Assets Loader para Escuelas IADE
// Este archivo maneja la carga de CSS y otros assets de forma dinámica

(function() {
    'use strict';
    
    // Configuración de assets
    const ASSETS = {
        css: [
            '/_astro/conocenos.BmyB0YrO.css'
        ],
        js: [
            '/_astro/LeadForm.astro_astro_type_script_index_0_lang.k-ELLiPq.js'
        ]
    };
    
    // Función para cargar CSS dinámicamente
    function loadCSS(href) {
        return new Promise((resolve, reject) => {
            // Verificar si ya está cargado
            if (document.querySelector(`link[href="${href}"]`)) {
                resolve();
                return;
            }
            
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.href = href;
            
            link.onload = () => {
                console.log(`✅ CSS cargado: ${href}`);
                resolve();
            };
            
            link.onerror = () => {
                console.error(`❌ Error cargando CSS: ${href}`);
                reject(new Error(`Error cargando CSS: ${href}`));
            };
            
            document.head.appendChild(link);
        });
    }
    
    // Función para cargar JavaScript dinámicamente
    function loadJS(src) {
        return new Promise((resolve, reject) => {
            // Verificar si ya está cargado
            if (document.querySelector(`script[src="${src}"]`)) {
                resolve();
                return;
            }
            
            const script = document.createElement('script');
            script.type = 'module';
            script.src = src;
            
            script.onload = () => {
                console.log(`✅ JavaScript cargado: ${src}`);
                resolve();
            };
            
            script.onerror = () => {
                console.error(`❌ Error cargando JavaScript: ${src}`);
                reject(new Error(`Error cargando JavaScript: ${src}`));
            };
            
            document.head.appendChild(script);
        });
    }
    
    // Función principal para cargar todos los assets
    async function loadAllAssets() {
        try {
            console.log('🚀 Iniciando carga de assets...');
            
            // Cargar CSS primero
            for (const cssFile of ASSETS.css) {
                await loadCSS(cssFile);
            }
            
            // Cargar JavaScript después
            for (const jsFile of ASSETS.js) {
                await loadJS(jsFile);
            }
            
            console.log('🎉 Todos los assets cargados exitosamente');
            
            // Disparar evento personalizado cuando todo esté listo
            window.dispatchEvent(new CustomEvent('assetsLoaded', {
                detail: { success: true }
            }));
            
        } catch (error) {
            console.error('❌ Error cargando assets:', error);
            
            // Disparar evento de error
            window.dispatchEvent(new CustomEvent('assetsLoaded', {
                detail: { success: false, error: error.message }
            }));
        }
    }
    
    // Función para verificar si los assets están cargados
    function areAssetsLoaded() {
        const cssLoaded = ASSETS.css.every(href => 
            document.querySelector(`link[href="${href}"]`)
        );
        
        const jsLoaded = ASSETS.js.every(src => 
            document.querySelector(`script[src="${src}"]`)
        );
        
        return cssLoaded && jsLoaded;
    }
    
    // Función para recargar assets si es necesario
    function reloadAssets() {
        // Remover assets existentes
        ASSETS.css.forEach(href => {
            const link = document.querySelector(`link[href="${href}"]`);
            if (link) link.remove();
        });
        
        ASSETS.js.forEach(src => {
            const script = document.querySelector(`script[src="${src}"]`);
            if (script) script.remove();
        });
        
        // Recargar
        return loadAllAssets();
    }
    
    // Iniciar carga cuando el DOM esté listo
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadAllAssets);
    } else {
        loadAllAssets();
    }
    
    // Exponer funciones globalmente
    window.IADEAssets = {
        loadAll: loadAllAssets,
        reload: reloadAssets,
        areLoaded: areAssetsLoaded,
        loadCSS: loadCSS,
        loadJS: loadJS
    };
    
    // Log de estado
    console.log('🔧 Assets Loader inicializado para Escuelas IADE');
    
})();
