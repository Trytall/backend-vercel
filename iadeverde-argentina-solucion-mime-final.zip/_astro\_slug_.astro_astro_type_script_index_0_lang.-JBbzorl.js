function v(){return Object.fromEntries(new URLSearchParams(location.search))}const e=v(),p=document.getElementById("resumenDatos"),f=document.getElementById("resumenCursos"),b=document.getElementById("insc-root")?.dataset.courseTitle||"",i=e.cursos||b,w={moron:"Morón",lomas:"Lomas de Zamora",avellaneda:"Avellaneda"},m=w[(e.sede||"").toLowerCase()]||"",g=(e.modalidad||"").toLowerCase()==="online";if(p){const n=`
        <div><strong>Nombre:</strong> ${e.nombre||"No especificado"}</div>
        <div><strong>DNI:</strong> ${e.dni||"No especificado"}</div>
        <div><strong>Email:</strong> ${e.email||"No especificado"}</div>
        <div><strong>Teléfono:</strong> ${e.telefono||"No especificado"}</div>
        <div><strong>Provincia:</strong> ${e.provincia||"No especificado"}</div>
        <div><strong>Localidad:</strong> ${e.localidad||"No especificado"}</div>
        <div><strong>Modalidad:</strong> ${e.modalidad||"Online"}</div>
        ${!g&&m?`<div><strong>Sede:</strong> ${m}</div>`:""}
      `;p.innerHTML=n}f&&(f.innerHTML=`<div class="bg-primary/10 text-primary px-3 py-2 rounded">${i}</div>`);(function(){const o={nombre:e.nombre||"",dni:e.dni||"",email:e.email||"",telefono:e.telefono||"",provincia:e.provincia||"",localidad:e.localidad||"",curso:i,sede:m};try{const s=sessionStorage.getItem("datosPago");(!s||s!==JSON.stringify(o))&&sessionStorage.setItem("datosPago",JSON.stringify(o))}catch{}})();const h="6LclXKIrAAAAAK3_BykpNKtYcMIbBw9P-aCGkdQh";(function(){if(typeof window>"u"||window.grecaptcha)return;const o=document.createElement("script");o.src=`https://www.google.com/recaptcha/api.js?render=${h}`,o.async=!0,document.head.appendChild(o)})();async function u(n){if(!g)return;let o;switch(n){case"contado":o=15e4;break;case"3cuotas":o=24e4;break;case"6cuotas":o=3e5;break;default:o=15e4}const s=(e.precioTest||e.precio||"").toString().replace(",","."),c=parseFloat(s);!Number.isNaN(c)&&c>0&&(o=c);try{sessionStorage.setItem("datosPago",JSON.stringify({nombre:e.nombre||"",dni:e.dni||"",email:e.email||"",telefono:e.telefono||"",provincia:e.provincia||"",localidad:e.localidad||"",curso:i,modalidad:e.modalidad||"Online",monto:o,plan:n}))}catch(r){console.error("Error guardando datos:",r)}try{const r=document.querySelectorAll("button");r.forEach(a=>a.disabled=!0);const d={items:[{title:i||"Curso IADE",quantity:1,currency_id:"ARS",unit_price:o}],back_urls:{success:window.location.origin+"/pago-exitoso",failure:window.location.origin+"/pago-fallido",pending:window.location.origin+"/pago-pendiente"},external_reference:`inscripcion_${Date.now()}`};console.log("Datos de preferencia:",d),console.log("Token MP:","APP_USR-194759099657032-080710-a9178f87cbb63114a063e8c046c86698-2239638495");const t=await fetch("https://api.mercadopago.com/checkout/preferences",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer APP_USR-194759099657032-080710-a9178f87cbb63114a063e8c046c86698-2239638495"},body:JSON.stringify(d)});if(console.log("Response status:",t.status),console.log("Response headers:",t.headers),!t.ok){const a=await t.text();throw console.error("Error response:",a),new Error(`Error HTTP: ${t.status} - ${a}`)}const l=await t.json();if(console.log("Preferencia creada:",l),l.id)window.location.href=`https://www.mercadopago.com.ar/checkout/v1/redirect?pref_id=${l.id}`;else throw new Error("No se pudo crear la preferencia");r.forEach(a=>a.disabled=!1)}catch(r){console.error("Error al crear preferencia:",r),alert("Error al procesar el pago. Por favor, intenta nuevamente."),document.querySelectorAll("button").forEach(t=>t.disabled=!1)}}function E(){const n=`Hola IADE! Me interesa el curso de ${i}.

Modalidad: ${e.modalidad||"Online"}

Mis datos:
Nombre: ${e.nombre||""}
DNI: ${e.dni||""}
Email: ${e.email||""}
Teléfono: ${e.telefono||""}
Provincia: ${e.provincia||""}
Localidad: ${e.localidad||""}

¿Podrían brindarme más información sobre el curso?`,o=`https://wa.me/5491130112419?text=${encodeURIComponent(n)}`;window.open(o,"_blank")}document.getElementById("btnContado")?.addEventListener("click",()=>u("contado"));document.getElementById("btn3Cuotas")?.addEventListener("click",()=>u("3cuotas"));document.getElementById("btn6Cuotas")?.addEventListener("click",()=>u("6cuotas"));document.getElementById("contactarAsesorBtn")?.addEventListener("click",n=>{n.preventDefault(),E()});
