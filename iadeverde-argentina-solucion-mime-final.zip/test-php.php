<?php
// Archivo de prueba simple para verificar que PHP esté funcionando
echo "PHP está funcionando correctamente en el servidor!";
echo "<br>Versión de PHP: " . phpversion();
echo "<br>Módulos cargados: ";
echo "<ul>";
foreach (get_loaded_extensions() as $ext) {
    echo "<li>$ext</li>";
}
echo "</ul>";
?>
