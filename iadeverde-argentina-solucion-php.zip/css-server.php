<?php
// Servidor de archivos CSS con tipo MIME correcto
header('Content-Type: text/css; charset=utf-8');
header('Cache-Control: public, max-age=31536000');
header('Access-Control-Allow-Origin: *');

$file = $_GET['file'] ?? '';
$file = str_replace(['../', './'], '', $file); // Prevenir directory traversal

if (empty($file) || !file_exists($file)) {
    http_response_code(404);
    echo "/* Archivo CSS no encontrado */";
    exit;
}

$ext = pathinfo($file, PATHINFO_EXTENSION);
if ($ext !== 'css') {
    http_response_code(400);
    echo "/* Solo se permiten archivos CSS */";
    exit;
}

// Leer y servir el archivo CSS
$content = file_get_contents($file);
if ($content === false) {
    http_response_code(500);
    echo "/* Error al leer el archivo */";
    exit;
}

echo $content;
?>
