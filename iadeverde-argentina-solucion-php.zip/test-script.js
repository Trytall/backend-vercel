// Archivo JavaScript de prueba para verificar tipos MIME
console.log('✅ JavaScript cargado correctamente desde js-server.php');

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ DOM cargado correctamente');
    
    // Agregar un mensaje de confirmación en la página
    const testDiv = document.querySelector('.test-mime');
    if (testDiv) {
        const jsTest = document.createElement('div');
        jsTest.style.cssText = 'background-color: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 5px; border: 1px solid #c3e6cb;';
        jsTest.innerHTML = '<strong>✅ JavaScript funcionando:</strong> El servidor PHP está sirviendo archivos JS correctamente.';
        testDiv.appendChild(jsTest);
    }
    
    // Verificar que el CSS esté funcionando
    const styles = window.getComputedStyle(document.body);
    const bgColor = styles.backgroundColor;
    console.log('🎨 Color de fondo del body:', bgColor);
    
    if (bgColor !== 'rgba(0, 0, 0, 0)' && bgColor !== 'transparent') {
        console.log('✅ CSS está funcionando correctamente');
    } else {
        console.log('❌ CSS no está funcionando');
    }
});

// Función de prueba
function testJavaScript() {
    alert('¡JavaScript está funcionando correctamente!');
    return true;
}

// Exponer la función para pruebas
window.testJavaScript = testJavaScript;
